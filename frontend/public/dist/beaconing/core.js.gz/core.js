/*!
 * Beaconing Teacher UI
 * ------------
 * Authors:
 * Elliott Judd <elliott.judd@hands-free.co.uk>
 */
!function(n){function e(o){if(t[o])return t[o].exports;var r=t[o]={i:o,l:!1,exports:{}};return n[o].call(r.exports,r,r.exports,e),r.l=!0,r.exports}var t={};e.m=n,e.c=t,e.d=function(n,t,o){e.o(n,t)||Object.defineProperty(n,t,{configurable:!1,enumerable:!0,get:o})},e.n=function(n){var t=n&&n.__esModule?function(){return n.default}:function(){return n};return e.d(t,"a",t),t},e.o=function(n,e){return Object.prototype.hasOwnProperty.call(n,e)},e.p="",e(e.s=16)}({16:function(n,e,t){"use strict";t(17);var o=t(19),r=function(n){return n&&n.__esModule?n:{default:n}}(o),u=new r.default,i=new window.Accessabar;window.beaconingCore=u,window.abarRuntime=i},17:function(n,e,t){"use strict";t(18)},18:function(n,e){},19:function(n,e,t){"use strict";function o(n,e){if(!(n instanceof e))throw new TypeError("Cannot call a class as a function")}Object.defineProperty(e,"__esModule",{value:!0});var r=function n(){o(this,n),this.test="Loaded!",console.log("[Beaconing Core] "+this.test)};e.default=r}});